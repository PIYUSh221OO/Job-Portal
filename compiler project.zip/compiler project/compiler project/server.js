require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const axios = require('axios');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('MongoDB connection error:', err));

// User Schema
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});
const User = mongoose.model('User', UserSchema);

// Signup Route
app.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) return res.status(400).json({ error: 'Username already exists' });
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword });
        await user.save();
        res.json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error registering user: ' + error.message });
    }
});

// Login Route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username });
        if (!user || !await bcrypt.compare(password, user.password)) {
            return res.status(401).json({ error: 'Invalid username or password' });
        }
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: 'Error logging in: ' + error.message });
    }
});

// Middleware for Authentication
function authenticate(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ error: 'Invalid token: ' + err.message });
        req.userId = decoded.id;
        next();
    });
}

// Run Code Route
app.post('/run', authenticate, async (req, res) => {
    const { code, language, customInput } = req.body;
    const languageIds = { c: 50, cpp: 54, java: 62 };

    try {
        console.log('Submitting code to Judge0:', { code, language, customInput });
        const response = await axios.post('https://judge0-ce.p.rapidapi.com/submissions', {
            source_code: code,
            language_id: languageIds[language] || 54,
            stdin: customInput || ''
        }, {
            headers: {
                'Content-Type': 'application/json',
                'x-rapidapi-key': process.env.RAPID_API_KEY,
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com'
            },
            maxRedirects: 20
        });

        const token = response.data.token;
        console.log('Submission token:', token);

        setTimeout(async () => {
            try {
                const result = await axios.get(`https://judge0-ce.p.rapidapi.com/submissions/${token}`, {
                    headers: {
                        'x-rapidapi-key': process.env.RAPID_API_KEY,
                        'x-rapidapi-host': 'judge0-ce.p.rapidapi.com'
                    },
                    maxRedirects: 20
                });
                console.log('Judge0 result:', result.data);
                let output = '';
                if (result.data.stdout) output += `Output:\n${result.data.stdout}`;
                if (result.data.stderr) output += `\nErrors:\n${result.data.stderr}`;
                if (result.data.compile_output) output += `\nCompilation Errors:\n${result.data.compile_output}`;
                if (result.data.time || result.data.memory) {
                    output += `\n\nExecution Time: ${result.data.time || 'N/A'} Secs\nMemory used: ${result.data.memory || 'N/A'} Bytes`;
                }

                res.json({ output: output || 'No output', time: result.data.time, memory: result.data.memory });
            } catch (getError) {
                console.error('Error fetching result:', getError.response ? getError.response.data : getError.message);
                res.status(500).json({ error: 'Error fetching result: ' + (getError.response ? getError.response.data.message : getError.message) });
            }
        }, 7000); // Increased timeout to 7 seconds for slower responses
    } catch (error) {
        console.error('Judge0 submission error:', error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'Error submitting code: ' + (error.response ? error.response.data.message : error.message) });
    }
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});