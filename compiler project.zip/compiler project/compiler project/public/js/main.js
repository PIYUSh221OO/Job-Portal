// Initialize CodeMirror with custom theme
const editor = CodeMirror.fromTextArea(document.getElementById('code'), {
    mode: 'text/x-csrc',
    lineNumbers: true,
    theme: 'custom-theme',
    lineWrapping: true,
    viewportMargin: Infinity
});

// Timer Variables
let timer;
let seconds = 0;
let isRunning = false;
let isPaused = false;

function updateTimerDisplay() {
    let mins = Math.floor(seconds / 60);
    let secs = seconds % 60;
    document.getElementById('timer').textContent = 
        `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

function startTimer() {
    if (!isRunning && !isPaused) {
        isRunning = true;
        document.getElementById('timer').classList.add('running');
        document.getElementById('timer').classList.remove('paused');
        timer = setInterval(() => {
            seconds++;
            updateTimerDisplay();
        }, 1000);
    }
}

function pauseTimer() {
    if (isRunning && !isPaused) {
        clearInterval(timer);
        isPaused = true;
        document.getElementById('timer').classList.remove('running');
        document.getElementById('timer').classList.add('paused');
    } else if (isRunning && isPaused) {
        isPaused = false;
        document.getElementById('timer').classList.remove('paused');
        document.getElementById('timer').classList.add('running');
        timer = setInterval(() => {
            seconds++;
            updateTimerDisplay();
        }, 1000);
    }
}

function stopTimer() {
    if (isRunning) {
        clearInterval(timer);
        isRunning = false;
        isPaused = false;
        document.getElementById('timer').classList.remove('running', 'paused');
    }
}

function resetTimer() {
    if (confirm('Are you sure you want to reset the timer?')) {
        stopTimer();
        seconds = 0;
        updateTimerDisplay();
    }
}

// Timer Event Listeners
document.getElementById('startTimer').addEventListener('click', startTimer);
document.getElementById('pauseTimer').addEventListener('click', pauseTimer);
document.getElementById('stopTimer').addEventListener('click', stopTimer);
document.getElementById('resetTimer').addEventListener('click', resetTimer);

// Auto-start timer when typing begins
editor.on('change', () => {
    if (!isRunning && !isPaused) {
        startTimer();
    }
});

// Update CodeMirror mode based on selected language
document.getElementById('language').addEventListener('change', () => {
    const language = document.getElementById('language').value;
    let mode = 'text/x-csrc';
    if (language === 'cpp') mode = 'text/x-c++src';
    if (language === 'java') mode = 'text/x-java';
    editor.setOption('mode', mode);
});

// Mode Toggle with Animation
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;

body.setAttribute('data-theme', 'dark');

themeToggle.addEventListener('click', () => {
    const currentTheme = body.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    body.setAttribute('data-theme', newTheme);
    themeToggle.textContent = newTheme === 'dark' ? '🌙' : '☀️';
});

// Full-screen Toggle with Animation
document.getElementById('fullscreen-toggle').addEventListener('click', () => {
    const dashboard = document.getElementById('dashboard');
    if (dashboard.requestFullscreen) {
        if (document.fullscreenElement) {
            document.exitFullscreen();
        } else {
            dashboard.requestFullscreen();
        }
    } else if (dashboard.mozRequestFullScreen) {
        if (document.mozFullScreenElement) {
            document.mozCancelFullScreen();
        } else {
            dashboard.mozRequestFullScreen();
        }
    } else if (dashboard.webkitRequestFullscreen) {
        if (document.webkitFullscreenElement) {
            document.webkitExitFullscreen();
        } else {
            dashboard.webkitRequestFullscreen();
        }
    } else if (dashboard.msRequestFullscreen) {
        if (document.msFullscreenElement) {
            document.msExitFullscreen();
        } else {
            dashboard.msRequestFullscreen();
        }
    }
    dashboard.classList.toggle('fullscreen');
});

// Toggle Form Function
function toggleForm(formType) {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const authTitle = document.getElementById('auth-title');
    const passwordError = document.getElementById('password-error');

    if (formType === 'signup') {
        loginForm.classList.add('hidden');
        signupForm.classList.remove('hidden');
        authTitle.textContent = 'Signup';
        passwordError.style.display = 'none'; // Reset error on toggle
    } else {
        signupForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
        authTitle.textContent = 'Login';
    }
}

// Custom Alert Function
function showAlert(message, type) {
    const modal = document.getElementById('alert-modal');
    const alertMessage = document.getElementById('alert-message');
    const alertIcon = document.getElementById('alert-icon');
    const modalContent = document.querySelector('.modal-content');

    alertMessage.textContent = message;
    modalContent.className = 'modal-content ' + type;
    alertIcon.className = 'fas fa-info-circle ' + type;

    if (type === 'success') {
        alertIcon.classList.add('success');
        alertIcon.classList.remove('error');
    } else if (type === 'error') {
        alertIcon.classList.add('error');
        alertIcon.classList.remove('success');
    }

    modal.classList.remove('hidden');
}

// Close Alert Function
function closeAlert() {
    const modal = document.getElementById('alert-modal');
    modal.classList.add('hidden');
}

// Signup Function with Password Validation
function signup() {
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;
    const passwordError = document.getElementById('password-error');

    if (password.length < 6) {
        passwordError.textContent = 'Password must be at least 6 characters';
        passwordError.style.display = 'block';
        return;
    }

    fetch('/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(res => res.text())
    .then(data => {
        if (data === 'User registered successfully') {
            showAlert(data, 'success');
        } else if (data === 'Username already exists') {
            showAlert(data, 'error');
        } else {
            showAlert('Error registering user', 'error');
        }
    })
    .catch(err => showAlert('Network error: ' + err.message, 'error'));
}

// Login Function
function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(res => res.json())
    .then(data => {
        if (data.token) {
            localStorage.setItem('token', data.token);
            showDashboard(username);
        } else if (data.error === 'Invalid username or password') {
            showAlert('Wrong password', 'error');
        } else {
            showAlert('Login failed', 'error');
        }
    })
    .catch(err => showAlert('Network error: ' + err.message, 'error'));
}

// Logout Function
function logout() {
    localStorage.removeItem('token');
    document.getElementById('auth').classList.remove('hidden');
    document.getElementById('dashboard').classList.add('hidden');
    toggleForm('login'); // Reset to login form on logout
}

// Show Dashboard
function showDashboard(username) {
    document.getElementById('auth').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    document.getElementById('username').innerText = username;
}

// Check if already logged in
if (localStorage.getItem('token')) {
    showDashboard('User');
}

// Toggle User Input Section
document.getElementById('useCustomInput').addEventListener('change', (event) => {
    const isChecked = event.target.checked;
    document.getElementById('input-section').style.display = isChecked ? 'block' : 'none';
});

// Submit User Input
function submitInput() {
    const customInput = document.getElementById('custom-input').value;
    document.getElementById('custom-input').value = '';
    document.getElementById('output').innerText += 'Input submitted: ' + customInput + '\n';
}

// Run Code Function
function runCode() {
    stopTimer();
    const codingTime = `${Math.floor(seconds / 60)} minute(s) and ${seconds % 60} second(s)`;
    resetTimer();

    const code = editor.getValue();
    const language = document.getElementById('language').value;
    const useCustomInput = document.getElementById('useCustomInput').checked;
    const customInput = useCustomInput ? document.getElementById('custom-input').value : '';
    const token = localStorage.getItem('token');

    fetch('/run', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ code, language, customInput })
    })
    .then(res => {
        if (!res.ok) {
            return res.text().then(text => { throw new Error(text); });
        }
        return res.json();
    })
    .then(data => {
        let output = data.output || 'No output';
        if (data.time || data.memory) {
            output += `\n\nExecution Time: ${data.time || 'N/A'} Secs\nMemory used: ${data.memory || 'N/A'} Bytes`;
        }
        output = `Coding Time: ${codingTime}\n\n${output}`;
        document.getElementById('output').innerText = output;
    })
    .catch(err => {
        const errorMessage = err.message;
        if (errorMessage.includes('jwt expired')) {
            logout();
            document.getElementById('output').innerText = `Error running code: Session expired, please log in again.`;
        } else {
            document.getElementById('output').innerText = `Error running code: ${errorMessage}`;
        }
    });
}

// Clear Output
function clearOutput() {
    document.getElementById('output').innerText = '';
}

// Show Settings (Placeholder)
function showSettings() {
    alert('Settings functionality not implemented');
}